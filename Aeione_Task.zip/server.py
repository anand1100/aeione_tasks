import socket
import queue
import threading
from _thread import start_new_thread

print_lock = threading.Lock()
dict = {}

def server_program():
    # get the hostname
    host = socket.gethostname()
    port = 5002  # initiate port no above 1024

    server_socket = socket.socket()  # get instance
    # look closely. The bind() function takes tuple as argument
    server_socket.bind((host, port))  # bind host address and port together

    # configure how many client the server can listen simultaneously
    server_socket.listen(3)

    while True:

        # accept new connection
        conn, address = server_socket.accept()
        print('Connected to :', address[0], ':', address[1])
        print("Connection from: " + str(address))
        start_new_thread(pushOperation,(conn,address))
        #start_new_thread(pollOperation,(conn,address))


        # data = input(' -> ')
        # conn.send(data.encode())  # send data to the client

def pushOperation(c,address):
    while True:

        # data received from client
        data = c.recv(1024)
        if (not str(address) in dict):
            dict[str(address)] = queue.Queue();

        # receive data stream. it won't accept data packet greater than 1024 bytes


        if not data:
            # if data is not received break
            break
        data = c.recv(1024).decode()
        dict[str(address)].put(data)
        with  open("file.txt","a+") as file:
            file.write(str(dict[str(address)].get())+","+str(address))
        print("Address")
        print(address)

        # reverse the given string from client
        #data = data[::-1]

        # send back reversed string to client
        #c.send(data)

    # connection closed
    c.close()

def pollOperation(c,address):
    while True:

        # data received from client
        data = c.recv(1024)
        if (not str(address) in dict):
            dict[str(address)] = queue.Queue();

        # receive data stream. it won't accept data packet greater than 1024 bytes


        if not data:
            # if data is not received break
            break
        data = c.recv(1024).decode()
        dict[str(address)].put(data)
        print("Address")
        print(address)
        print(dict[str(address)].qsize)

        # reverse the given string from client
        #data = data[::-1]

        # send back reversed string to client
        #c.send(data)

    # connection closed
    c.close()

if __name__ == '__main__':
    server_program()
