import socket
import time

def client_program():
    host = socket.gethostname()  # as both code is running on same pc
    port = 5002  # socket server port number

    client_socket = socket.socket()  # instantiate
    client_socket.connect((host, port))  # connect to the server
    x=1

    while True:
        client_socket.send(str(x).encode())  # send message

        #print('Received from server: ' + data)  # show in terminal

        x=int(x)+1
        time.sleep(2)

    client_socket.close()  # close the connection


if __name__ == '__main__':
    client_program()
